// import React, { useEffect, useState } from 'react';
// import { Link } from 'react-router-dom';
// import {
//   Paper,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   TablePagination,
//   TableSortLabel,
//   TextField,
//   Button,
// } from '@mui/material';
// import axios from 'axios';





// const MatchingProfiles: React.FC = () => {
//   const [order, setOrder] = useState<'asc' | 'desc'>('asc');
//   const [orderBy, setOrderBy] = useState<string>('');
//   const [page, setPage] = useState(0);
//   const [rowsPerPage, setRowsPerPage] = useState(10);
//   const [data, setData] = useState<Data>({ results: [], count: 0 });
//   const [search, setSearch] = useState<string>('');

  

//   const  = 'http://103.214.132.20:8000/auth/Get_prof_list_match/';

//   useEffect(() => {
//     fetchData();
//   }, [page, rowsPerPage, order, orderBy, search]);

//   const fetchData = async () => {
//     try {
//       const response = await axios.get(apiEndpoint, {
//         params: {
//           page: page + 1,
//           page_size: rowsPerPage,
//           ordering: order === 'asc' ? orderBy : `-${orderBy}`,
//           search: `profile_id:${search}`,
//         },
//       });
//       setData(response.data);
//     } catch (error) {
//       console.error('Error fetching data:', error);
//     }
//   };

//   const handleRequestSort = (property: string) => {
//     const isAsc = orderBy === property && order === 'asc';
//     setOrder(isAsc ? 'desc' : 'asc');
//     setOrderBy(property);
//   };

//   const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setSearch(event.target.value);
//     setPage(0);
//   };

//   const handleChangePage = (_event: unknown, newPage: number) => {
//     setPage(newPage);
//   };

//   const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setRowsPerPage(+event.target.value);
//     setPage(0);
//   };

//   const handleDelete = async (ContentId: number) => {
//     if (!ContentId) {
//       console.error('Error: Missing ID for the row to delete');
//       return;
//     }

//     const confirmed = window.confirm('Are you sure you want to delete this item?');

//     if (!confirmed) return;

//     try {
//       await axios.delete();
//       fetchData(); // Refresh the data after deletion
//     } catch (error) {
//       console.error('Error deleting data:', error);
//     }
//   };

//   return (
//     <Paper className="w-full">
//       <div className="w-full text-right px-2">
//         <TextField
//           label="Search by Profile ID"
//           variant="outlined"
//           margin="normal"
//           value={search}
//           onChange={handleSearchChange}
//         />
//       </div>

//       <TableContainer className="bg-white">
//         <Table stickyHeader>
//           <TableHead>
//             <TableRow>
//               {columns.map((column) => (
//                 <TableCell
//                   key={column.id}
//                   align={column.align}
//                   style={{ minWidth: column.minWidth }}
//                 >
//                   <TableSortLabel
//                     className="!text-red-600 !text-base !text-md text-nowrap font-semibold"
//                     active={orderBy === column.id}
//                     direction={orderBy === column.id ? order : 'asc'}
//                     onClick={() => handleRequestSort(column.id)}
//                   >
//                     {column.label}
//                   </TableSortLabel>
//                 </TableCell>
//               ))}
//               <TableCell className="!text-red-600 !text-base !text-nowrap !font-semibold">
//                 Actions
//               </TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {data.results.map((row, index) => (
//               <TableRow hover role="checkbox" tabIndex={-1} key={index}>
//                 {columns.map((column) => {
//                   const value = row[column.id];
//                   return (
//                     <TableCell key={column.id} align={column.align}>
//                       {column.format && typeof value === 'number'
//                         ? column.format(value)
//                         : value}
//                     </TableCell>
//                   );
//                 })}
//                 <TableCell>
//                   <Button >
//                     Edit
//                   </Button>
//                   <Button >Delete</Button>
//                 </TableCell>
//               </TableRow>
//             ))}
//           </TableBody>
//         </Table>
//       </TableContainer>
//       <TablePagination
//         rowsPerPageOptions={[10, 25, 100]}
//         component="div"
//         count={data.count}
//         rowsPerPage={rowsPerPage}
//         page={page}
//         onPageChange={handleChangePage}
//         onRowsPerPageChange={handleChangeRowsPerPage}
//       />
//     </Paper>
//   );
// };

// export default MatchingProfiles;


// import React, { useEffect, useState } from 'react';
// import {
//   Paper,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   TablePagination,
//   TableSortLabel,
//   TextField,
//   Button,
//   Grid,
// } from '@mui/material';
// import axios from 'axios';

// interface Profile {
//   profile_id: string;
//   profile_name: string;
//   profile_img: string;
//   profile_age: string;
//   profile_gender: string;
//   height: string;
//   weight: string;
//   degree: string;
//   profession: string;
//   location: string;
//   wish_list: number;
// }

// interface Data {
//   profiles: Profile[];
//   count: number;
// }

// const MatchingProfiles: React.FC = () => {
//   const [order, setOrder] = useState<'asc' | 'desc'>('asc');
//   const [orderBy, setOrderBy] = useState<string>('profile_id');
//   const [page, setPage] = useState(0);
//   const [rowsPerPage, setRowsPerPage] = useState(10);
//   const [data, setData] = useState<Data>({ profiles: [], count: 0 });
//   const [search, setSearch] = useState<string>('');
//   const [commonSearch, setCommonSearch] = useState<string>('');

//   const apiEndpoint = 'http://103.214.132.20:8000/auth/Get_prof_list_match/';

//   useEffect(() => {
//     fetchData();
//   }, [page, rowsPerPage, order, orderBy, commonSearch]); // Added commonSearch

//   const fetchData = async () => {
//     try {
//       const response = await axios.post(apiEndpoint, {
//         page: page + 1,
//         page_size: rowsPerPage,
//         ordering: order === 'asc' ? orderBy : `-${orderBy}`,
//         search: search,
//         // Assume common_search field can handle multiple fields
//         profile_id:search,
//         // common_search: commonSearch,
//       });
//       setData(response.data);
//     } catch (error) {
//       console.error('Error fetching data:', error);
//       // Optionally, show an error message to the user
//     }
//   };

//   const handleRequestSort = (property: string) => {
//     const isAsc = orderBy === property && order === 'asc';
//     setOrder(isAsc ? 'desc' : 'asc');
//     setOrderBy(property);
//   };

//   const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setSearch(event.target.value);
//   };

//   const handleCommonSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setCommonSearch(event.target.value);
//   };

//   const handleChangePage = (_event: unknown, newPage: number) => {
//     setPage(newPage);
//   };

//   const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setRowsPerPage(+event.target.value);
//     setPage(0);
//   };

//   const handleSubmit = () => {
//     setPage(0); // Reset to the first page
//     fetchData();
//   };

//   const columns = [
//     { id: 'profile_img', label: 'Image' },
//     { id: 'profile_id', label: 'Profile ID' },
//     { id: 'profile_name', label: 'Name' },
//     { id: 'profile_age', label: 'Age' },
//     { id: 'profile_gender', label: 'Gender' },
//     { id: 'height', label: 'Height' },
//     { id: 'weight', label: 'Weight' },
//     { id: 'degree', label: 'Degree' },
//     { id: 'profession', label: 'Profession' },
//     { id: 'location', label: 'Location' },
//   ];

//   return (
//     <>
//       <h1 className="text-2xl font-bold mb-4">Search matching profile</h1>

//       <Paper className="w-full">
//         <Grid container spacing={2} justifyContent="center" alignItems="center">
//           <Grid item xs={12} md={6}>
//             <Grid container spacing={2} justifyContent="center" alignItems="center">
//               <Grid item>
//                 <TextField
//                   label="Search by Profile ID"
//                   variant="outlined"
//                   margin="normal"
//                   value={search}
//                   onChange={handleSearchChange}
//                   style={{ width: '400px' }}
//                 />
//               </Grid>
//               <Grid item>
//                 <Button
//                   variant="contained"
//                   color="primary"
//                   onClick={handleSubmit}
//                   style={{ height: '56px', marginTop: '8px' }}
//                 >
//                   Submit
//                 </Button>
//               </Grid>
//             </Grid>
//           </Grid>

//           <Grid item xs={12} md={5} style={{ textAlign: 'right' }}>
//             <TextField
//               label="Common Search (Name/ID/Age)"
//               variant="outlined"
//               margin="normal"
//               value={commonSearch}
//               onChange={handleCommonSearchChange}
//               style={{ marginTop: '30px', width: '250px' }}
//             />
//           </Grid>
//         </Grid>

//         <TableContainer className="bg-white">
//           <Table stickyHeader>
//             <TableHead>
//               <TableRow>
//                 {columns.map((column) => (
//                   <TableCell
//                     key={column.id}
//                     align="left"
//                     style={{ minWidth: 100 }}
//                   >
//                     <TableSortLabel
//                       className="!text-red-600 !text-base !text-md text-nowrap font-semibold"
//                       active={orderBy === column.id}
//                       direction={orderBy === column.id ? order : 'asc'}
//                       onClick={() => handleRequestSort(column.id)}
//                     >
//                       {column.label}
//                     </TableSortLabel>
//                   </TableCell>
//                 ))}
//                 <TableCell className="!text-red-600 !text-base !text-nowrap !font-semibold">
//                   Actions
//                 </TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {data.profiles.map((row) => (
//                 <TableRow hover role="checkbox" tabIndex={-1} key={row.profile_id}>
//                   {columns.map((column) => (
//                     <TableCell key={column.id} align="left">
//                       {column.id === 'profile_img' ? (
//                         <img
//                           src={row[column.id as keyof Profile]}
//                           alt="Profile"
//                           style={{ width: 50, height: 50, borderRadius: '50%' }}
//                         />
//                       ) : (
//                         row[column.id as keyof Profile]
//                       )}
//                     </TableCell>
//                   ))}
//                   <TableCell>
//                     <Button>Edit</Button>
//                     <Button>Delete</Button>
//                   </TableCell>
//                 </TableRow>
//               ))}
//             </TableBody>
//           </Table>
//         </TableContainer>
//         <TablePagination
//           rowsPerPageOptions={[10, 25, 100]}
//           component="div"
//           count={data.count}
//           rowsPerPage={rowsPerPage}
//           page={page}
//           onPageChange={handleChangePage}
//           onRowsPerPageChange={handleChangeRowsPerPage}
//         />
//       </Paper>
//     </>
//   );
// };

// export default MatchingProfiles;



// import React, { useEffect, useState } from 'react';
// import { useLocation } from 'react-router-dom';
// import {
//   Paper,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   TablePagination,
//   TableSortLabel,
//   TextField,
//   Button,
//   Grid,
// } from '@mui/material';
// import axios from 'axios';

// interface Profile {
//   profile_id: string;
//   profile_name: string;
//   profile_img: string;
//   profile_age: string;
//   profile_gender: string;
//   height: string;
//   weight: string;
//   degree: string;
//   profession: string;
//   location: string;
//   wish_list: number;
// }

// interface Data {
//   profiles: Profile[];
//   count: number;
// }

// const useQuery = () => {
//   return new URLSearchParams(useLocation().search);
// };

// const MatchingProfiles: React.FC = () => {
//   const [order, setOrder] = useState<'asc' | 'desc'>('asc');
//   const [orderBy, setOrderBy] = useState<string>('profile_id');
//   const [page, setPage] = useState(0);
//   const [rowsPerPage, setRowsPerPage] = useState(10);
//   const [data, setData] = useState<Data>({ profiles: [], count: 0 });
//   const [commonSearch, setCommonSearch] = useState<string>('');

//   const query = useQuery();
//   const profileId = query.get('profile_id');

//   const apiEndpoint = 'http://103.214.132.20:8000/auth/Get_prof_list_match/';

//   useEffect(() => {
//     fetchData();
//   }, [page, rowsPerPage, order, orderBy, profileId]);

//   const fetchData = async () => {
//     try {
//       const response = await axios.post(apiEndpoint, {
//         page: page + 1,
//         page_size: rowsPerPage,
//         ordering: order === 'asc' ? orderBy : `-${orderBy}`,
//         search: profileId || commonSearch,
//         profile_id: profileId || '',
//       });
//       setData(response.data);
//     } catch (error) {
//       console.error('Error fetching data:', error);
//     }
//   };

//   const handleRequestSort = (property: string) => {
//     const isAsc = orderBy === property && order === 'asc';
//     setOrder(isAsc ? 'desc' : 'asc');
//     setOrderBy(property);
//   };

//   const handleCommonSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setCommonSearch(event.target.value);
//     fetchData(); // Fetch data whenever the search input changes
//   };

//   const handleChangePage = (_event: unknown, newPage: number) => {
//     setPage(newPage);
//   };

//   const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setRowsPerPage(+event.target.value);
//     setPage(0);
//   };

//   const columns = [
//     { id: 'profile_img', label: 'Image' },
//     { id: 'profile_id', label: 'Profile ID' },
//     { id: 'profile_name', label: 'Name' },
//     { id: 'profile_age', label: 'Age' },
//     { id: 'profile_gender', label: 'Gender' },
//     { id: 'height', label: 'Height' },
//     { id: 'weight', label: 'Weight' },
//     { id: 'degree', label: 'Degree' },
//     { id: 'profession', label: 'Profession' },
//     { id: 'location', label: 'Location' },
//   ];

//   // Filter profiles locally based on commonSearch
//   const filteredProfiles = data.profiles.filter((profile) => {
//     const searchTerm = commonSearch.toLowerCase();
//     return (
//       profile.profile_id.toLowerCase().includes(searchTerm) ||
//       profile.profile_name.toLowerCase().includes(searchTerm) ||
//       profile.profile_age.toLowerCase().includes(searchTerm)
//     );
//   });

//   return (
//     <>
//       <h1 className="text-2xl font-bold mb-4">Search Matching Profile</h1>
//       <Paper className="w-full">
//         <Grid item xs={12} md={5} style={{ textAlign: 'right' }}>
//           <TextField
//             label="Common Search (Name/ID/Age)"
//             variant="outlined"
//             margin="normal"
//             value={commonSearch}
//             onChange={handleCommonSearchChange}
//             style={{ marginTop: '30px', width: '250px' }}
//           />
//         </Grid>

//         <TableContainer className="bg-white">
//           <Table stickyHeader>
//             <TableHead>
//               <TableRow>
//                 {columns.map((column) => (
//                   <TableCell
//                     key={column.id}
//                     align="left"
//                     style={{ minWidth: 100 }}
//                   >
//                     <TableSortLabel
//                       className="!text-red-600 !text-base !text-md text-nowrap font-semibold"
//                       active={orderBy === column.id}
//                       direction={orderBy === column.id ? order : 'asc'}
//                       onClick={() => handleRequestSort(column.id)}
//                     >
//                       {column.label}
//                     </TableSortLabel>
//                   </TableCell>
//                 ))}
//                 <TableCell className="!text-red-600 !text-base !text-nowrap !font-semibold">
//                   Actions
//                 </TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {filteredProfiles.map((row) => (
//                 <TableRow hover role="checkbox" tabIndex={-1} key={row.profile_id}>
//                   {columns.map((column) => (
//                     <TableCell key={column.id} align="left">
//                       {column.id === 'profile_img' ? (
//                         <img
//                           src={String(row[column.id as keyof Profile])}
//                           alt="Profile"
//                           style={{ width: 50, height: 50, borderRadius: '50%' }}
//                         />
//                       ) : (
//                         row[column.id as keyof Profile]
//                       )}
//                     </TableCell>
//                   ))}
//                   <TableCell>
//                     <Button>Edit</Button>
//                     <Button>Delete</Button>
//                   </TableCell>
//                 </TableRow>
//               ))}
//             </TableBody>
//           </Table>
//         </TableContainer>
//         <TablePagination
//           rowsPerPageOptions={[10, 25, 100]}
//           component="div"
//           count={data.count}
//           rowsPerPage={rowsPerPage}
//           page={page}
//           onPageChange={handleChangePage}
//           onRowsPerPageChange={handleChangeRowsPerPage}
//         />
//       </Paper>
//     </>
//   );
// };

// export default MatchingProfiles;


import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  TableSortLabel,
  TextField,
  Button,
  Grid,
} from '@mui/material';
import axios from 'axios';

interface Profile {
  profile_id: string;
  profile_name: string;
  profile_img: string;
  profile_age: string;
  profile_gender: string;
  height: string;
  weight: string;
  degree: string;
  profession: string;
  location: string;
  wish_list: number;
}

interface Data {
  profiles: Profile[];
  count: number;
}

const useQuery = () => {
  return new URLSearchParams(useLocation().search);
};

const MatchingProfiles: React.FC = () => {
  const [order, setOrder] = useState<'asc' | 'desc'>('asc');
  const [orderBy, setOrderBy] = useState<string>('profile_id');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [data, setData] = useState<Data>({ profiles: [], count: 0 });
  const [commonSearch, setCommonSearch] = useState<string>('');

  const query = useQuery();
  const profileId = query.get('profile_id');

  const apiEndpoint = 'http://103.214.132.20:8000/auth/Get_prof_list_match/';

  useEffect(() => {
    fetchData();
  }, [page, rowsPerPage, order, orderBy, profileId]);

  const fetchData = async () => {
    try {
      const response = await axios.post(apiEndpoint, {
        page: page + 1,
        page_size: rowsPerPage,
        ordering: order === 'asc' ? orderBy : `-${orderBy}`,
        search: profileId || commonSearch,
        profile_id: profileId || '',
      });
      setData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleRequestSort = (property: string) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleCommonSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setCommonSearch(event.target.value);
    fetchData(); // Fetch data whenever the search input changes
  };

  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const columns = [
    { id: 'profile_img', label: 'Image' },
    { id: 'profile_id', label: 'Profile ID' },
    { id: 'profile_name', label: 'Name' },
    { id: 'profile_age', label: 'Age' },
    { id: 'profile_gender', label: 'Gender' },
    { id: 'height', label: 'Height' },
    { id: 'weight', label: 'Weight' },
    { id: 'degree', label: 'Degree' },
    { id: 'profession', label: 'Profession' },
    { id: 'location', label: 'Location' },
  ];

  // Filter profiles locally based on commonSearch
  const filteredProfiles = data.profiles.filter((profile) => {
    const searchTerm = commonSearch.toLowerCase();
    return (
      profile.profile_id.toLowerCase().includes(searchTerm) ||
      profile.profile_name.toLowerCase().includes(searchTerm) ||
      profile.profile_age.toLowerCase().includes(searchTerm)
    );
  });

  // Sort profiles locally based on the order and orderBy state
  const sortedProfiles = filteredProfiles.sort((a, b) => {
    const aValue = a[orderBy as keyof Profile];
    const bValue = b[orderBy as keyof Profile];

    if (aValue < bValue) return order === 'asc' ? -1 : 1;
    if (aValue > bValue) return order === 'asc' ? 1 : -1;
    return 0;
  });

  return (
    <>
      <h1 className="text-2xl font-bold mb-4">Search Matching Profile</h1>
      <Paper className="w-full">
        <Grid item xs={12} md={5}  style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <TextField
            label="Common Search (Name/ID/Age)"
            variant="outlined"
            margin="normal"
            value={commonSearch}
            onChange={handleCommonSearchChange}
            
            style={{ marginTop: '30px', width: '250px', marginRight: '20px'}}
          />
        </Grid>

        <TableContainer className="bg-white">
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell
                    key={column.id}
                    align="left"
                    style={{ minWidth: 100 }}
                  >
                    <TableSortLabel
                      className="!text-red-600 !text-base !text-md text-nowrap font-semibold"
                      active={orderBy === column.id}
                      direction={orderBy === column.id ? order : 'asc'}
                      onClick={() => handleRequestSort(column.id)}
                    >
                      {column.label}
                    </TableSortLabel>
                  </TableCell>
                ))}
                <TableCell className="!text-red-600 !text-base !text-nowrap !font-semibold">
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {sortedProfiles.map((row) => (
                <TableRow hover role="checkbox" tabIndex={-1} key={row.profile_id}>
                  {columns.map((column) => (
                    <TableCell key={column.id} align="left">
                      {column.id === 'profile_img' ? (
                        <img
                          src={String(row[column.id as keyof Profile])}
                          alt="Profile"
                          style={{ width: 50, height: 50, borderRadius: '50%' }}
                        />
                      ) : (
                        row[column.id as keyof Profile]
                      )}
                    </TableCell>
                  ))}
                  <TableCell>
                    <Button>Edit</Button>
                    <Button>Delete</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[10, 25, 100]}
          component="div"
          count={data.count}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>
    </>
  );
};

export default MatchingProfiles;
