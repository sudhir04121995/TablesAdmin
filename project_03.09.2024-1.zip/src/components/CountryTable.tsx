// import React, { useEffect, useState } from 'react';
// import {
//     Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Dialog,
//     DialogActions, DialogContent, DialogTitle, TextField, Snackbar, Alert, IconButton
// } from '@mui/material';
// import { getCountries, addCountry, updateCountry, deleteCountry } from '../services/api';
// import DeleteIcon from '@mui/icons-material/Delete';
// import EditIcon from '@mui/icons-material/Edit';

// const CountryTable: React.FC = () => {
//     const [countries, setCountries] = useState<any[]>([]);
//     const [open, setOpen] = useState(false);
//     const [currentCountry, setCurrentCountry] = useState<any>(null);
//     const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
//     const [deleteCountryId, setDeleteCountryId] = useState<string | null>(null);
//     const [snackbarOpen, setSnackbarOpen] = useState(false);
//     const [snackbarMessage, setSnackbarMessage] = useState('');
//     const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'error'>('success');

//     useEffect(() => {
//         fetchCountries();
//     }, []);

//     const fetchCountries = async () => {
//         try {
//             const response = await getCountries();
//             setCountries(response.data);
//         } catch (error) {
//             console.error('Error fetching countries:', error);
//             setSnackbarMessage('Error fetching countries');
//             setSnackbarSeverity('error');
//             setSnackbarOpen(true);
//         }
//     };

//     const handleOpen = (country: any = null) => {
//         setCurrentCountry(country);
//         setOpen(true);
//     };

//     const handleClose = () => {
//         setOpen(false);
//         setCurrentCountry(null);
//     };

//     const handleSave = async () => {
//         try {
//             if (currentCountry.id) {
//                 await updateCountry(currentCountry.id, currentCountry);
//                 setSnackbarMessage('Country updated successfully');
//             } else {
//                 await addCountry(currentCountry);
//                 setSnackbarMessage('Country added successfully');
//             }
//             setSnackbarSeverity('success');
//             fetchCountries();
//             handleClose();
//         } catch (error) {
//             console.error('Error saving country:', error);
//             setSnackbarMessage(`Error saving country: ${error.response?.data || error.message}`);
//             setSnackbarSeverity('error');
//         } finally {
//             setSnackbarOpen(true);
//         }
//     };

//     const handleDeleteDialogOpen = (id: string) => {
//         setDeleteCountryId(id);
//         setDeleteDialogOpen(true);
//     };

//     const handleDeleteDialogClose = () => {
//         setDeleteDialogOpen(false);
//         setDeleteCountryId(null);
//     };

//     const handleDelete = async () => {
//         if (!deleteCountryId) return;
//         try {
//             await deleteCountry(deleteCountryId);
//             setSnackbarMessage('Country deleted successfully');
//             setSnackbarSeverity('success');
//             fetchCountries();
//         } catch (error) {
//             console.error('Error deleting country:', error);
//             setSnackbarMessage(`Error deleting country: ${error.response?.data || error.message}`);
//             setSnackbarSeverity('error');
//         } finally {
//             setSnackbarOpen(true);
//             handleDeleteDialogClose();
//         }
//     };

//     const handleSnackbarClose = () => {
//         setSnackbarOpen(false);
//     };

//     return (
//         <Paper>
//             <Button onClick={() => handleOpen()}>Add Country</Button>
//             <TableContainer>
//                 <Table>
//                     <TableHead>
//                         <TableRow>
//                             <TableCell>ID</TableCell>
//                             <TableCell>Name</TableCell>
//                             <TableCell>Status</TableCell>
//                             <TableCell>Actions</TableCell>
//                         </TableRow>
//                     </TableHead>
//                     <TableBody>
//                         {countries.map((country) => (
//                             <TableRow key={country.id}>
//                                 <TableCell>{country.id}</TableCell>
//                                 <TableCell>{country.name}</TableCell>
//                                 <TableCell>{country.is_active ? 'Active' : 'Inactive'}</TableCell>
//                                 <TableCell>
//                                     <IconButton onClick={() => handleOpen(country)}>
//                                         <EditIcon />
//                                     </IconButton>
//                                     <IconButton onClick={() => handleDeleteDialogOpen(country.id)}>
//                                         <DeleteIcon />
//                                     </IconButton>
//                                 </TableCell>
//                             </TableRow>
//                         ))}
//                     </TableBody>
//                 </Table>
//             </TableContainer>
//             <Dialog open={open} onClose={handleClose}>
//                 <DialogTitle>{currentCountry?.id ? 'Edit Country' : 'Add Country'}</DialogTitle>
//                 <DialogContent>
//                     <TextField
//                         label="Name"
//                         value={currentCountry?.name || ''}
//                         onChange={(e) => setCurrentCountry({ ...currentCountry, name: e.target.value })}
//                         fullWidth
//                     />
//                 </DialogContent>
//                 <DialogActions>
//                     <Button onClick={handleClose}>Cancel</Button>
//                     <Button onClick={handleSave}>Save</Button>
//                 </DialogActions>
//             </Dialog>
//             <Dialog open={deleteDialogOpen} onClose={handleDeleteDialogClose}>
//                 <DialogTitle>Delete Country</DialogTitle>
//                 <DialogContent>
//                     Are you sure you want to delete this country?
//                 </DialogContent>
//                 <DialogActions>
//                     <Button onClick={handleDeleteDialogClose}>Cancel</Button>
//                     <Button onClick={handleDelete}>Delete</Button>
//                 </DialogActions>
//             </Dialog>
//             <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={handleSnackbarClose}>
//                 <Alert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: '100%' }}>
//                     {snackbarMessage}
//                 </Alert>
//             </Snackbar>
//         </Paper>
//     );
// };

// export default CountryTable;

// import React, { useEffect, useState } from 'react';
// import {
//     Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Dialog,
//     DialogActions, DialogContent, DialogTitle, TextField, Snackbar, Alert, IconButton, CircularProgress
// } from '@mui/material';
// import { getCountries, addCountry, updateCountry, deleteCountry } from '../services/api';
// import DeleteIcon from '@mui/icons-material/Delete';
// import EditIcon from '@mui/icons-material/Edit';
// import axios from 'axios';

// const CountryTable: React.FC = () => {
//     const [countries, setCountries] = useState<any[]>([]);
//     const [loading, setLoading] = useState<boolean>(true);
//     const [open, setOpen] = useState(false);
//     const [currentCountry, setCurrentCountry] = useState<any>(null);
//     const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
//     const [deleteCountryId, setDeleteCountryId] = useState<string | null>(null);
//     const [snackbarOpen, setSnackbarOpen] = useState(false);
//     const [snackbarMessage, setSnackbarMessage] = useState('');
//     const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'error'>('success');

//     useEffect(() => {
//         fetchCountries();
//     }, []);

//     const fetchCountries = async () => {
//         setLoading(true);
//         try {
//             const response = await axios.get(`http://103.214.132.20:8000/api/countries`);
//             //await getCountries();
//             setCountries(response.data);
//         } catch (error) {
//             console.error('Error fetching countries:', error);
//             setSnackbarMessage('Error fetching countries');
//             setSnackbarSeverity('error');
//             setSnackbarOpen(true);
//         } finally {
//             setLoading(false);
//         }
//     };

//     const handleOpen = (country: any = null) => {
//         setCurrentCountry(country);
//         setOpen(true);
//     };

//     const handleClose = () => {
//         setOpen(false);
//         setCurrentCountry(null);
//     };

//     const handleSave = async () => {
//         if (!currentCountry?.name) {
//             setSnackbarMessage('Country name cannot be empty');
//             setSnackbarSeverity('error');
//             setSnackbarOpen(true);
//             return;
//         }
//         try {
//             if (currentCountry.id) {
//                 await updateCountry(currentCountry.id, currentCountry);
//                 setSnackbarMessage('Country updated successfully');
//             } else {
//                 await addCountry(currentCountry);
//                 setSnackbarMessage('Country added successfully');
//             }
//             setSnackbarSeverity('success');
//             fetchCountries();
//             handleClose();
//         } catch (error) {
//             console.error('Error saving country:', error);
//             setSnackbarMessage(`Error saving country: ${error.response?.data || error.message}`);
//             setSnackbarSeverity('error');
//         } finally {
//             setSnackbarOpen(true);
//         }
//     };

//     const handleDeleteDialogOpen = (id: string) => {
//         setDeleteCountryId(id);
//         setDeleteDialogOpen(true);
//     };

//     const handleDeleteDialogClose = () => {
//         setDeleteDialogOpen(false);
//         setDeleteCountryId(null);
//     };

//     const handleDelete = async () => {
//         if (!deleteCountryId) return;
//         try {
//             await deleteCountry(deleteCountryId);
//             setSnackbarMessage('Country deleted successfully');
//             setSnackbarSeverity('success');
//             fetchCountries();
//         } catch (error) {
//             console.error('Error deleting country:', error);
//             setSnackbarMessage(`Error deleting country: ${error.response?.data || error.message}`);
//             setSnackbarSeverity('error');
//         } finally {
//             setSnackbarOpen(true);
//             handleDeleteDialogClose();
//         }
//     };

//     const handleSnackbarClose = () => {
//         setSnackbarOpen(false);
//     };

//     return (
//         <Paper>
//             <Button variant="contained" onClick={() => handleOpen()} style={{ marginBottom: '20px' }}>
//                 Add Country
//             </Button>
//             {loading ? (
//                 <CircularProgress />
//             ) : (
//                 <TableContainer>
//                     <Table>
//                         <TableHead>
//                             <TableRow>
//                                 <TableCell>ID</TableCell>
//                                 <TableCell>Name</TableCell>
//                                 <TableCell>Status</TableCell>
//                                 <TableCell>Actions</TableCell>
//                             </TableRow>
//                         </TableHead>
//                         <TableBody>
//                             {countries.map((country) => (
//                                 <TableRow key={country.id}>
//                                     <TableCell>{country.id}</TableCell>
//                                     <TableCell>{country.name}</TableCell>
//                                     <TableCell>{country.is_active ? 'Active' : 'Inactive'}</TableCell>
//                                     <TableCell>
//                                         <IconButton onClick={() => handleOpen(country)}>
//                                             <EditIcon />
//                                         </IconButton>
//                                         <IconButton onClick={() => handleDeleteDialogOpen(country.id)}>
//                                             <DeleteIcon />
//                                         </IconButton>
//                                     </TableCell>
//                                 </TableRow>
//                             ))}
//                         </TableBody>
//                     </Table>
//                 </TableContainer>
//             )}
//             <Dialog open={open} onClose={handleClose}>
//                 <DialogTitle>{currentCountry?.id ? 'Edit Country' : 'Add Country'}</DialogTitle>
//                 <DialogContent>
//                     <TextField
//                         label="Name"
//                         value={currentCountry?.name || ''}
//                         onChange={(e) => setCurrentCountry({ ...currentCountry, name: e.target.value })}
//                         fullWidth
//                     />
//                 </DialogContent>
//                 <DialogActions>
//                     <Button onClick={handleClose}>Cancel</Button>
//                     <Button onClick={handleSave} variant="contained">Save</Button>
//                 </DialogActions>
//             </Dialog>
//             <Dialog open={deleteDialogOpen} onClose={handleDeleteDialogClose}>
//                 <DialogTitle>Delete Country</DialogTitle>
//                 <DialogContent>
//                     Are you sure you want to delete this country?
//                 </DialogContent>
//                 <DialogActions>
//                     <Button onClick={handleDeleteDialogClose}>Cancel</Button>
//                     <Button onClick={handleDelete} variant="contained" color="error">Delete</Button>
//                 </DialogActions>
//             </Dialog>
//             <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={handleSnackbarClose}>
//                 <Alert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: '100%' }}>
//                     {snackbarMessage}
//                 </Alert>
//             </Snackbar>
//         </Paper>
//     );
// };

// export default CountryTable;


// import React, { useEffect, useState } from 'react';
// import {
//     Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Dialog,
//     DialogActions, DialogContent, DialogTitle, TextField, Snackbar, Alert, IconButton, CircularProgress
// } from '@mui/material';
// import { getCountries, addCountry, updateCountry, deleteCountry } from '../services/api';
// import DeleteIcon from '@mui/icons-material/Delete';
// import EditIcon from '@mui/icons-material/Edit';
// import axios from 'axios';

// const CountryTable: React.FC = () => {
//     const [countries, setCountries] = useState<any[]>([]);
//     const [loading, setLoading] = useState<boolean>(true);
//     const [open, setOpen] = useState(false);
//     const [currentCountry, setCurrentCountry] = useState<any>(null);
//     const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
//     const [deleteCountryId, setDeleteCountryId] = useState<string | null>(null);
//     const [snackbarOpen, setSnackbarOpen] = useState(false);
//     const [snackbarMessage, setSnackbarMessage] = useState('');
//     const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'error'>('success');

//     useEffect(() => {
//         fetchCountries();
//     }, []);

//     const fetchCountries = async () => {
//         setLoading(true);
//         try {
//             const response = await getCountries();
//             setCountries(response.data);
//         } catch (error) {
//             handleApiError(error, 'Error fetching countries');
//         } finally {
//             setLoading(false);
//         }
//     };

//     const handleOpen = (country: any = null) => {
//         setCurrentCountry(country);
//         setOpen(true);
//     };

//     const handleClose = () => {
//         setOpen(false);
//         setCurrentCountry(null);
//     };

//     const handleApiError = (error: any, defaultMessage: string) => {
//         console.error(defaultMessage, error);
//         setSnackbarMessage(error.response?.data || error.message || defaultMessage);
//         setSnackbarSeverity('error');
//         setSnackbarOpen(true);
//     };

//     const handleSave = async () => {
//         if (!currentCountry?.name?.trim()) {
//             setSnackbarMessage('Country name cannot be empty');
//             setSnackbarSeverity('error');
//             setSnackbarOpen(true);
//             return;
//         }
//         try {
//             if (currentCountry.id) {
//                 await updateCountry(currentCountry.id, currentCountry);
//                 setSnackbarMessage('Country updated successfully');
//             } else {
//                 await addCountry(currentCountry);
//                 setSnackbarMessage('Country added successfully');
//             }
//             setSnackbarSeverity('success');
//             fetchCountries();
//             handleClose();
//         } catch (error) {
//             handleApiError(error, 'Error saving country');
//         }
//     };

//     const handleDeleteDialogOpen = (id: string) => {
//         setDeleteCountryId(id);
//         setDeleteDialogOpen(true);
//     };

//     const handleDeleteDialogClose = () => {
//         setDeleteDialogOpen(false);
//         setDeleteCountryId(null);
//     };

//     const handleDelete = async () => {
//         if (!deleteCountryId) return;
//         try {
//             await deleteCountry(deleteCountryId);
//             setSnackbarMessage('Country deleted successfully');
//             setSnackbarSeverity('success');
//             fetchCountries();
//         } catch (error) {
//             handleApiError(error, 'Error deleting country');
//         } finally {
//             handleDeleteDialogClose();
//         }
//     };

//     const handleSnackbarClose = () => {
//         setSnackbarOpen(false);
//     };

//     return (
//         <Paper style={{ padding: '20px' }}>
//             <Button variant="contained" onClick={() => handleOpen()} style={{ marginBottom: '20px' }}>
//                 Add Country
//             </Button>
//             {loading ? (
//                 <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '200px' }}>
//                     <CircularProgress />
//                 </div>
//             ) : (
//                 <TableContainer>
//                     <Table>
//                         <TableHead>
//                             <TableRow>
//                                 <TableCell>ID</TableCell>
//                                 <TableCell>Name</TableCell>
//                                 <TableCell>Status</TableCell>
//                                 <TableCell>Actions</TableCell>
//                             </TableRow>
//                         </TableHead>
//                         <TableBody>
//                             {countries.map((country) => (
//                                 <TableRow key={country.id}>
//                                     <TableCell>{country.id}</TableCell>
//                                     <TableCell>{country.name}</TableCell>
//                                     <TableCell>{country.is_active ? 'Active' : 'Inactive'}</TableCell>
//                                     <TableCell>
//                                         <IconButton onClick={() => handleOpen(country)} aria-label="edit">
//                                             <EditIcon />
//                                         </IconButton>
//                                         <IconButton onClick={() => handleDeleteDialogOpen(country.id)} aria-label="delete">
//                                             <DeleteIcon />
//                                         </IconButton>
//                                     </TableCell>
//                                 </TableRow>
//                             ))}
//                         </TableBody>
//                     </Table>
//                 </TableContainer>
//             )}
//             <Dialog open={open} onClose={handleClose}>
//                 <DialogTitle>{currentCountry?.id ? 'Edit Country' : 'Add Country'}</DialogTitle>
//                 <DialogContent>
//                     <TextField
//                         label="Name"
//                         value={currentCountry?.name || ''}
//                         onChange={(e) => setCurrentCountry({ ...currentCountry, name: e.target.value })}
//                         fullWidth
//                     />
//                 </DialogContent>
//                 <DialogActions>
//                     <Button onClick={handleClose}>Cancel</Button>
//                     <Button onClick={handleSave} variant="contained">Save</Button>
//                 </DialogActions>
//             </Dialog>
//             <Dialog open={deleteDialogOpen} onClose={handleDeleteDialogClose}>
//                 <DialogTitle>Delete Country</DialogTitle>
//                 <DialogContent>
//                     Are you sure you want to delete this country?
//                 </DialogContent>
//                 <DialogActions>
//                     <Button onClick={handleDeleteDialogClose}>Cancel</Button>
//                     <Button onClick={handleDelete} variant="contained" color="error">Delete</Button>
//                 </DialogActions>
//             </Dialog>
//             <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={handleSnackbarClose}>
//                 <Alert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: '100%' }}>
//                     {snackbarMessage}
//                 </Alert>
//             </Snackbar>
//         </Paper>
//     );
// };

// export default CountryTable;



import React, { useState, useEffect, useMemo } from 'react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
  Container,
  Typography,
  Box,
  Grid,
} from '@mui/material';
import { getCountries, addCountry, updateCountry, deleteCountry } from '../services/api';
import Reuse from './Basic/Reuse';
import Notification, { notify, notifyDelete } from './TostNotification';

interface Country {
  id: number;
  name: string;
  is_active: boolean;
}

interface ColumnConfig<T> {
  field: keyof T;
  headerName: string;
  sortable: boolean;
}

const CountryTable: React.FC = () => {
  const [countries, setCountries] = useState<Country[]>([]);
  const [newCountryName, setNewCountryName] = useState('');
  const [showPopup, setShowPopup] = useState(false);
  const [editCountryId, setEditCountryId] = useState<number | null>(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [countryToDelete, setCountryToDelete] = useState<number | null>(null);

  useEffect(() => {
    fetchCountries();
  }, []);

  const fetchCountries = async () => {
    const response = await getCountries();
    setCountries(response.data);
  };

  const addOrUpdateCountry = async () => {
    const countryData = { name: newCountryName, is_active: true };
    if (editCountryId) {
      const response = await updateCountry(editCountryId.toString(), countryData);
      if (response.status >= 200 && response.status <= 201) {
        notify('Country updated successfully');
      }
    } else {
      const response = await addCountry(countryData);
      if (response.status >= 200 && response.status <= 201) {
        notify('Country added successfully');
      }
    }
    setNewCountryName('');
    setShowPopup(false);
    setEditCountryId(null);
    fetchCountries();
  };

  const handleEditCountry = (country: Country) => {
    setEditCountryId(country.id);
    setNewCountryName(country.name);
    setShowPopup(true);
  };

//   const confirmDeleteCountry = async () => {
//     if (countryToDelete !== null) {
//       const response = await deleteCountry(countryToDelete.toString());
//       if (response.status >= 200 && response.status <= 201) {
//         notifyDelete('Country deleted successfully');
//       }
//       setCountryToDelete(null);
//       setDeleteConfirmation(false);
//       fetchCountries();
//     }
//   };

const handleDeleteCountry = (countryId: number) => {
    setCountryToDelete(countryId);
    setDeleteConfirmation(true);
  };
  
  const confirmDeleteCountry = async () => {
    if (countryToDelete !== null) {
      const response = await deleteCountry(countryToDelete.toString());
      if (response.status >= 200 && response.status <= 201) {
        notifyDelete('Country deleted successfully');
      }
      setCountryToDelete(null);
      setDeleteConfirmation(false);
      fetchCountries();
    } else {
      console.error("No country selected for deletion.");
    }
  };
  
  const columns: ColumnConfig<Country>[] = useMemo(() => [
    { field: 'id', headerName: 'ID', sortable: true },
    { field: 'name', headerName: 'Country Name', sortable: true },
    { field: 'is_active', headerName: 'Status', sortable: true },
  ], []);

//   const handleDeleteCountry = (country: Country) => {
//     setCountryToDelete(country.id);
//     setDeleteConfirmation(true);
//   };

const handleSearchChange = (searchText: string) => {
    // Filter the countries based on the searchText
    const filteredCountries = countries.filter((country) =>
      country.name.toLowerCase().includes(searchText.toLowerCase())
    );
    setCountries(filteredCountries);
  };
  
  return (
    <Container style={{ backgroundColor: 'white', padding: '20px' }}>
      <Reuse
        data={countries}
        columns={columns}
        handleEdit={handleEditCountry}
        handleSearchChange={handleSearchChange}
        handleDelete={(country) => handleDeleteCountry(country.id)}
        setShowPopup={setShowPopup}
        idField="id"
        title="Country List"
      />

      {showPopup && (
        <Dialog
          open={showPopup}
          onClose={() => setShowPopup(false)}
          maxWidth="sm"
          sx={{ background: '#f5f0ef ' }}
        >
          <Box>
            <DialogTitle
              style={{
                color: 'red',
                textAlign: 'center',
                fontWeight: 'bold',
                marginTop: '20px',
                fontSize: '50px',
              }}
            >
              {editCountryId ? 'Edit Country' : 'Add Country'}
            </DialogTitle>
          </Box>
          <DialogContent style={{ padding: '50px 50px' }}>
            <Grid container rowSpacing={3} columnSpacing={{ xs: 1, sm: 2 }}>
              <Grid item xs={12} sm={12}>
                <TextField
                  label="Country Name"
                  value={newCountryName}
                  onChange={(e) => setNewCountryName(e.target.value)}
                  fullWidth
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions style={{ marginRight: '43px' }}>
            <Button
              style={{
                background: '#FFFDFF',
                color: 'red',
                boxShadow: '0px 8px 16px rgba(0, 0, 0, 0.2)',
              }}
              onClick={() => setShowPopup(false)}
            >
              Cancel
            </Button>
            <Button
              style={{
                background: 'red',
                color: 'white',
                boxShadow: '0px 8px 16px rgba(0, 0, 0, 0.4)',
              }}
              onClick={addOrUpdateCountry}
              disabled={!newCountryName.trim()}
            >
              {editCountryId ? 'Update' : 'Submit'}
            </Button>
          </DialogActions>
        </Dialog>
      )}

      {deleteConfirmation && (
        <Dialog
          open={deleteConfirmation}
          onClose={() => setDeleteConfirmation(false)}
        >
          <DialogTitle>Confirm Delete</DialogTitle>
          <DialogContent>
            <Typography>
              Are you sure you want to delete this country?
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDeleteConfirmation(false)}>
              Cancel
            </Button>
            <Button onClick={confirmDeleteCountry} color="secondary">
              Delete
            </Button>
          </DialogActions>
        </Dialog>
      )}

      <Notification />
    </Container>
  );
};

export default CountryTable;
